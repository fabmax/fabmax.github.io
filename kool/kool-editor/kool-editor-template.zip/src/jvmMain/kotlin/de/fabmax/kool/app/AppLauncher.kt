package de.fabmax.kool.app

import de.fabmax.kool.KoolApplication

fun main() = KoolApplication {
    App().launchStandalone(ctx)
}