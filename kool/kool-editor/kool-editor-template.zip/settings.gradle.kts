rootProject.name = "kool-editor-template"
